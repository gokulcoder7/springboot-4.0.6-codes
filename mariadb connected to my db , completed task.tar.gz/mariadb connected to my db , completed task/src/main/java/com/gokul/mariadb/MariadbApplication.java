package com.gokul.mariadb;

import com.gokul.mariadb.dao.Student;
import com.gokul.mariadb.dao.StudentDAO;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MariadbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MariadbApplication.class, args);
	}




	@Bean
	public CommandLineRunner clr(StudentDAO sd){

		return runner->{

			savestudent(sd);
		};


	}

	private void savestudent(StudentDAO sd) {


        Student stu=new Student("eren","yagar","eren@ganal.com");

		sd.save(stu);

		System.out.println("id generated===== "+stu.getId());
	}


}
