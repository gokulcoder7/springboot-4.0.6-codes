package com.gokul.mariadb.dao;

import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;





@Repository
public class StudentDAOimpl implements StudentDAO{


    private EntityManager em;

    @Autowired
    public StudentDAOimpl(EntityManager em) {
        this.em = em;
    }

    @Transactional
    @Override
    public void save(Student student) {
        em.persist(student);

    }
}
