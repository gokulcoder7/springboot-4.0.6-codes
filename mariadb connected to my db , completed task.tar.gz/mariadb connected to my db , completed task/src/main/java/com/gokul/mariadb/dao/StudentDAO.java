package com.gokul.mariadb.dao;

public interface StudentDAO {

    void save(Student student);



}
