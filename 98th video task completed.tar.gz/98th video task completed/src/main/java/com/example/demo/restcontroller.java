package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class restcontroller {




    @GetMapping("/students")
    public List<Student> getstu(){
        List<Student> li=new ArrayList<>();
        li.add(new Student(7,"gokul"));

        li.add(new Student(9,"bhai hu"));


        return li;

    }




}
