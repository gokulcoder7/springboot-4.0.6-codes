package com.gokul.restdao_120;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.List;



@Repository
public class DAOimpl implements DAO{



    EntityManager myem;

    public DAOimpl(EntityManager theem){
        myem=theem ;

    }

    @Override
    public List<Employee> findall() {

        TypedQuery<Employee> theq=myem.createQuery("From Employee",Employee.class);
        List<Employee> li=theq.getResultList();

        return li;
    }
}
