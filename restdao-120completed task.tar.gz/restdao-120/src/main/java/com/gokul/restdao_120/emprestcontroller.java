package com.gokul.restdao_120;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class emprestcontroller {

       private DAO myd;

    public emprestcontroller(DAO thed) {


        myd = thed;
    }



    @GetMapping("/employees")
    public List<Employee> getempl(DAO d){
        return myd.findall();

    }


}
