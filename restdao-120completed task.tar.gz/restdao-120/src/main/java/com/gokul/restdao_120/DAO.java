package com.gokul.restdao_120;

import java.util.List;

public interface DAO {


    List<Employee> findall();


}
