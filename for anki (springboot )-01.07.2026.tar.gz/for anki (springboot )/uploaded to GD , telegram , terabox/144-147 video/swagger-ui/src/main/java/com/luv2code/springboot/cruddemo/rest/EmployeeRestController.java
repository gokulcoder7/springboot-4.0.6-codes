package com.luv2code.springboot.cruddemo.rest;

import com.luv2code.springboot.cruddemo.entity.Employee;
import com.luv2code.springboot.cruddemo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {

    private EmployeeService employeeService;



    private JsonMapper jm;

    @Autowired
    public EmployeeRestController(EmployeeService theEmployeeService, JsonMapper jm2) {
        employeeService = theEmployeeService;
        jm=jm2;
    }

    // expose "/employees" and return a list of employees
    @GetMapping("/employees")
    public List<Employee> findAll() {
        return employeeService.findAll();
    }

    // add mapping for GET /employees/{employeeId}

    @GetMapping("/employees/{employeeId}")
    public Employee getEmployee(@PathVariable int employeeId) {

        Employee theEmployee = employeeService.findById(employeeId);

        if (theEmployee == null) {
            throw new RuntimeException("Employee id not found - " + employeeId);
        }

        return theEmployee;
    }

    // add mapping for POST /employees - add new employee

    @PostMapping("/employees")
    public Employee addEmployee(@RequestBody Employee theEmployee) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        theEmployee.setId(0);

        Employee dbEmployee = employeeService.save(theEmployee);

        return dbEmployee;
    }





    @PatchMapping("/employees/{eid}")
    public Employee patchemp(@PathVariable int eid,@RequestBody Map<String,Object> patchpay){

        Employee tempemp= employeeService.findById(eid) ;
        if(tempemp==null){

            throw new RuntimeException("emp not found =="+eid);

        }

        if(patchpay.containsKey("id")){
            throw new RuntimeException("emp id is not allowed in reques body =="+eid);
        }


        Employee patchemp1= jm.updateValue(tempemp,patchpay);
        Employee dbemp=employeeService.save(patchemp1);


        return dbemp;
    }












    // add mapping for PUT /employees - update existing employee

    @PutMapping("/employees")
    public Employee updateEmployee(@RequestBody Employee theEmployee) {

        Employee dbEmployee = employeeService.save(theEmployee);

        return dbEmployee;
    }

}














