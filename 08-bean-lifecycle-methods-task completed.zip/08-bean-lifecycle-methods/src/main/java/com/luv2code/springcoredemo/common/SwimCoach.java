package com.luv2code.springcoredemo.common;

public class SwimCoach implements Coach{
    @Override
    public String getDailyWorkout() {
        return "Practice swiming for 75 minutes----------- swim in beach  print this text";




    }
}
